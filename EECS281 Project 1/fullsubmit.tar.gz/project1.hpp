//Project Identifier: 950181F63D0A883F183EC0A5CC67B19928FE896A
//  project1.hpp
//  EECS281 Project 1
//
//  Created by Lydia Kim on 1/13/23.
//

#ifndef project1_hpp
#define project1_hpp

#include <stdio.h>

#endif /* project1_hpp */
